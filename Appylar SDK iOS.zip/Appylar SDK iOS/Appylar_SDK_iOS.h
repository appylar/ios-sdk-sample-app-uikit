//
//  Appylar_SDK_iOS.h
//  Appylar SDK iOS
//
//  Created by 5Exceptions_Mac1 on 16/12/22.
//

#import <Foundation/Foundation.h>

//! Project version number for Appylar_SDK_iOS.
FOUNDATION_EXPORT double Appylar_SDK_iOSVersionNumber;

//! Project version string for Appylar_SDK_iOS.
FOUNDATION_EXPORT const unsigned char Appylar_SDK_iOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Appylar_SDK_iOS/PublicHeader.h>


