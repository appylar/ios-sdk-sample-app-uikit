//
//  AppylerDelegate.swift
//  Appylar SDK iOS
//
//  Created by 5Exceptions on 20/12/22.
//

import UIKit

//MARK :- Delegate methods for event callback
public protocol AppylarDelegate {
    func onInitialized()
    func onError(error : String)
}

public protocol BannerViewDelegate {
    func onNoBanner()
    func onBannerShown()
}

public protocol InterstitialDelegate {
    func onNoInterstitial()
    func onInterstitialShown()
    func onInterstitialClosed()
}
