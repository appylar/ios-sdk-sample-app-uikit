//
//  AdOrientation.swift
//  Appylar SDK iOS
//
//  Created by 5Exceptions on 04/01/23.
//

import Foundation

public enum AdOrientation : String {
    case portrait = "portrait"
    case landscape = "landscape"
}
