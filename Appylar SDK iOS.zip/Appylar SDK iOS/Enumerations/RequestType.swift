//
//  RequestType.swift
//  Appylar mobile SDK
//
//  Created by 5Exceptions on 15/12/22.
//

import UIKit

enum RequestType : String {
    case post = "POST"
}
