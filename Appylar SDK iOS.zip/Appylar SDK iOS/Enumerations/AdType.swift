//
//  AdType.swift
//  Appylar SDK iOS
//
//  Created by 5Exceptions on 02/01/23.
//

import Foundation

public enum AdType : String {
    case banner = "banner"
    case interstitial = "interstitial"
}
