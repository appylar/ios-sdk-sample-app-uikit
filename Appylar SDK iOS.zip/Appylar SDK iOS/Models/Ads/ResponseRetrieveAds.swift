//
//  ResponseRetrieveAds.swift
//  Appylar mobile SDK
//
//  Created by 5Exceptions on 15/12/22.
//

import UIKit

internal class ResponseRetrieveAds : NSObject {
    var ads : [Advertisement]?
    /**
     *Perform intilization with json*
     *Return void*
     */
    internal func initWithJson(json: [String : AnyObject]) {
        if let results = json[Constants.result] as? [[String :Any]] {
            var advertisements = [Advertisement]()
            for result in results {
                let advertisment = Advertisement()
                if let ad = result[Constants.ad] as? [String :Any] {
                    let adsize = AdSize()
                    if let height = ad[Constants.height] as? Double {
                        adsize.height = height
                    }
                    if let orientation = ad[Constants.orientation] as? String {
                        if orientation == AdOrientation.portrait.rawValue {
                            adsize.orientation = .portrait
                        }else {
                            adsize.orientation = .landscape
                        }
                    }
                    if let scale = ad[Constants.scale] as? Double {
                        adsize.scale = scale
                    }
                    if let type = ad[Constants.type] as? String {
                        adsize.type = type
                    }
                    if let width = ad[Constants.width] as? Double {
                        adsize.width = width
                    }
                    advertisment.ad = adsize
                }
                if let expires_at = result[Constants.expiresAt] as? String {
                    advertisment.expiresAt = expires_at
                }
                if let html = result[Constants.html] as? String {
                    advertisment.html = html
                }
                if let url = result[Constants.url] as? String {
                    advertisment.url = url
                }
                advertisements.append(advertisment)
            }
            self.ads = advertisements
        }
    }
}
