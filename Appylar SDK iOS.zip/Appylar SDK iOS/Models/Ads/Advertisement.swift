//
//  Advertisement.swift
//  Appylar mobile SDK
//
//  Created by 5Exceptions on 15/12/22.
//

import UIKit

public class Advertisement : NSObject {
    var ad : AdSize?
    var html : String?
    var url : String?
    var isExpired: Bool? {
        if timeToExpire ?? 0 > 0 {
            return false
        } else {
            return true
        }
    }
    var timeToExpire : TimeInterval? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
        let date = dateFormatter.date(from: self.expiresAt ?? "")
        let diffSeconds = (date?.timeIntervalSinceReferenceDate ?? 0) - Date().timeIntervalSinceReferenceDate
        return diffSeconds
    }
    var adDisplayed = false
    var expiresAt : String?
}
