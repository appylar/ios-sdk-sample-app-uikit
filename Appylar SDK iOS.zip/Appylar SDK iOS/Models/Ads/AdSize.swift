//
//  Advertisement.swift
//  Appylar mobile SDK
//
//  Created by 5Exceptions on 15/12/22.
//

import UIKit

class AdSize : NSObject {
    var type : String?
    var width : Double?
    var height : Double?
    var scale : Double?
    var orientation: AdOrientation?
}
