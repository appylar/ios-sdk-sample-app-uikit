//
//  Appylar.swift
//  Appylar mobile SDK
//
//  Created by 5Exceptions on 15/12/22.
//

import UIKit
import WebKit
import SystemConfiguration
//MARK :- Sesion Initiate
public class AppylarManager {
    static var timerForApiCallOn500 = Timer()
    static var advertisements = [Advertisement]()
    static var bannerAds = [Advertisement]()
    static var interstitialAds = [Advertisement]()
    static var timer = Timer()
    static var parameters = [String:[String]?]()
    
    /// set orientations you want to be allowed in this property by default
    public static var supportedOrientation = UIInterfaceOrientationMask.all
    
    //    override init() {}
    internal static var delegate : AppylarDelegate?
    internal static var bannerDelegate : BannerViewDelegate?
    internal static var interstitialDelegate : InterstitialDelegate?
    public static func setEventListener(delegate : AppylarDelegate,bannerDelegate: BannerViewDelegate,interstitialDelegate : InterstitialDelegate){
        self.delegate = delegate
        self.bannerDelegate = bannerDelegate
        self.interstitialDelegate = interstitialDelegate
    }
    
    /**
     *Initialize session with valid app key*
     *Retrieve ads is calling when Session token is not empty*
     *@return void*
     */
    public static func Init(appKey: String, adTypes: [AdType],orientations: [AdOrientation],testMode : Bool) {
        
        var orientationRawValue = [String]()
        let identifier = Bundle.main.bundleIdentifier ?? ""
        if toCheckValidationToInitialize(appKey: appKey, orientation: orientations, adType: adTypes)  && Session.isInitialized == false {
            Session.isInitialized = true
            for or in orientations {
                if !orientationRawValue.contains(or.rawValue){
                    orientationRawValue.append(or.rawValue)
                }
            }
            if Session.printLog{
                print(orientationRawValue)
            }
            let locale = Locale.current
            var countryCode = ""
            if #available(iOS 16, *) {
                if let value = locale.region?.identifier {
                    countryCode = value
                }
            } else {
                if let value = locale.regionCode {
                    countryCode = value
                }
            }
            let param = [
                Constants.width: Int(UIScreen.main.bounds.width),
                Constants.density: UIScreen.main.scale,
                Constants.height: Int(UIScreen.main.bounds.height),
                Constants.country: countryCode,
                Constants.language: NSLocale.current.languageCode ?? "en",
                Constants.appKey: appKey,
                Constants.appId: identifier,
                Constants.testMode: testMode,
                Constants.orientations: orientationRawValue
            ] as [String : Any]
            Session.printLog = false
            var arrAdTypes: [AdType] = []
            for AdType in adTypes {
                if !arrAdTypes.contains(AdType) {
                    arrAdTypes.append(AdType)
                }
            }
            if Session.sessionToken.isEmpty == true && checkInternetConnection() {
                ApiManager().callApiToCreateSessionToken(params: param, orientations : orientations, adTypes: arrAdTypes, completion: {
                    self.retrieveAds(isForBuffer: false,combination: [:], completion: {_ in
                    })
                })
                Session.isSessionCreated = true
            } else if checkInternetConnection() == false {
                if Session.printLog{ print("No Internet Available.....!") }
                if Session.isSessionCreated == false {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 30 , execute: {
                        Session.isInitialized = false
                        self.Init(appKey: appKey, adTypes: adTypes, orientations: orientations, testMode: testMode)
                    })
                }
            }
        }
        
        func toCheckValidationToInitialize(appKey: String, orientation: [AdOrientation], adType: [AdType]) -> Bool {
            
            if appKey.isEmpty == false && orientation.isEmpty == false && adType.isEmpty == false {
                return true
            } else {
                if appKey.isEmpty{
                    self.delegate?.onError(error: "{\"error\": \(Constants.errorInvalid), \"message\": \"\(Constants.appKeyEmpty)\"}")
                }
                else if orientation.isEmpty {
                    self.delegate?.onError(error: "{\"error\": \(Constants.errorInvalid), \"message\": \"\(Constants.orientationEmpty)\"}")
                }
                else if adType.isEmpty {
                    self.delegate?.onError(error: "{\"error\": \(Constants.errorInvalid), \"message\": \"\(Constants.adTypeEmpty) \"}")
                }
                return false
            }
        }
    }
    /**
     *Parameters is set *
     *Set Banner height and age *
     *Clear the existing data and reload ads with new parameters*
     *@return void*
     */
    public static func setParameters(dict : [String:[String]?]) {
        for (key, value) in dict {
            self.parameters[key] = value
        }
        self.timer.invalidate()
        self.timerForApiCallOn500.invalidate()
        advertisements.removeAll()
        bannerAds.removeAll()
        interstitialAds.removeAll()
        self.retrieveAds(isForBuffer: false, combination: [:], completion: {_ in })
    }
    /**
     *Retrieve Ads in buffer*
     *Call Api for retrive ads with new parameters and combinations*
     *@return void*
     */
    internal static func retrieveAds(isForBuffer: Bool,combination: [String: Any], completion: @escaping ([String:Any]) -> ()) {
        
        if Session.sessionToken.isEmpty == false {
            var extraParameters =  [String:[String]]()
            var combinations: [String: Any]
            var ArrAdtypes = [String]()
            var ArrOrDict = [String : [String]]()
            for (key,value) in self.parameters {
                if value != nil {
                    extraParameters[key] = value
                }
            }
            for type in Session.adTypes  {
                ArrAdtypes.append(type.rawValue)
            }
            for or in Session.orientations {
                ArrOrDict[or.rawValue] = ArrAdtypes
            }
            if isForBuffer {
                combinations = combination
            } else {
                combinations = ArrOrDict
            }
            //if wait time then have to wait for the time to call API
            DispatchQueue.main.asyncAfter(deadline: .now() + Double(Session.waitTime)) {
                ApiManager().callApiToRetrieveAds(extraParameters: extraParameters, combinations: combinations, completion: { json in
                    completion(json)
                })
            }
        }
    }
    
    /**
     *Returns the first ad in the buffer for the given ad type*
     *
     *@param orientations*
     *@param adTypes*
     *@return void*
     */
    
    internal static func bufferNewAdsIfNeeded( advertisement: [Advertisement], combination: [String: Any]){
        var combinationToRetrieveAds = [String : [String]]()
        var potraitAdsBelowBufferLimit = [String]()
        var lanscapeAdsBelowBufferLimit = [String]()
        var ArrAdOrientation = [AdOrientation]()
        var arrAdtype = Set<AdType>()
        for type in combination.keys  {
            ArrAdOrientation.append(AdOrientation(rawValue: type)!)
            if let values = combination[type] as? [Any]{
                for or in values {
                    arrAdtype.insert(AdType(rawValue: or as? String ?? "")!)
                }
            }
        }
        for ortant in ArrAdOrientation {
            for adsTypeInBuffer in arrAdtype {
                let actualData = filterAdsByType(filtertype: adsTypeInBuffer, filterOrinetation: ortant, advertisement: adsTypeInBuffer == .banner ? self.bannerAds : self.interstitialAds)
                if actualData.count < Session.minimumBufferLimit {
                    if ortant == .portrait {
                        if potraitAdsBelowBufferLimit.contains(adsTypeInBuffer.rawValue){
                            break
                        }else{
                            potraitAdsBelowBufferLimit.append(adsTypeInBuffer.rawValue)
                        }
                    }
                    if ortant == .landscape {
                        if lanscapeAdsBelowBufferLimit.contains(adsTypeInBuffer.rawValue){
                            break
                        }else{
                            lanscapeAdsBelowBufferLimit.append(adsTypeInBuffer.rawValue)
                        }
                    }
                }
            }
            if potraitAdsBelowBufferLimit.count > 0 {
                for _ in potraitAdsBelowBufferLimit {
                    combinationToRetrieveAds[AdOrientation.portrait.rawValue] = potraitAdsBelowBufferLimit
                }
            }
            if lanscapeAdsBelowBufferLimit.count > 0 {
                for _ in lanscapeAdsBelowBufferLimit {
                    combinationToRetrieveAds[AdOrientation.landscape.rawValue] = lanscapeAdsBelowBufferLimit
                }
            }
        }
        if combinationToRetrieveAds.count > 0 {
            if Session.printLog {print("API call from buffer if needed..!")}
            self.retrieveAds(isForBuffer: true,combination: combinationToRetrieveAds, completion: {_ in
            })
            combinationToRetrieveAds.removeAll()
        }
    }
    
    /**
     *Filter Ads according to their type *
     *Return the array of ad orientations *
     */
    private  static func filterAdsByType(filtertype : AdType, filterOrinetation : AdOrientation, advertisement: [Advertisement]) -> [Advertisement] {
        var filteredAds = [Advertisement]()
        for ads in advertisement {
            if filtertype == .banner || filtertype == .interstitial {
                if ads.ad?.orientation == .portrait {
                    if ads.isExpired == false {
                        filteredAds.append(ads)
                    }
                }else if ads.ad?.orientation == .landscape {
                    if ads.isExpired == false {
                        filteredAds.append(ads)
                    }
                }
            }
        }
        return filteredAds
    }
    /**
     *Check ad is expired or not*
     *If expires then remove it from adtype array and main array as well*
     *@return void*
     */
    
    static func getTime() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
        let timeString = dateFormatter.string(from: Date())
        
        return timeString
    }
    
    internal static func checkExpireAdsPerAdType(){
        let advert = AppylarManager.advertisements
        for (_,item) in advert.enumerated() {
            if item.adDisplayed || (item.isExpired ?? false) {
                guard let indexOfItem = AppylarManager.advertisements.firstIndex(of: item) else { return }
                AppylarManager.advertisements.remove(at: indexOfItem)
            }
        }
        AppylarManager.bannerAds = AppylarManager().filterAds(filtertype: .banner)
        AppylarManager.interstitialAds = AppylarManager().filterAds(filtertype: .interstitial)
    }
    
    internal  func filterAds(filtertype : AdType) -> [Advertisement] {
        var filteredAds = [Advertisement]()
        for ads in AppylarManager.advertisements {
            if filtertype == .banner {
                if ads.ad?.type == AdType.banner.rawValue {
                    filteredAds.append(ads)
                }
            } else {
                if ads.ad?.type == AdType.interstitial.rawValue {
                    filteredAds.append(ads)
                }
            }
        }
        return filteredAds
    }
    
    /**
     Check for app key , orientation, and adtype one of this is empty return false
     otherwise return true
     */
    //TODO - Remove this its only for testing purpose
    public static func manualAdRemovalFromBuffer(adType: AdType){
        if adType == .banner{
            self.advertisements.removeAll()
            self.advertisements.append(contentsOf:  self.interstitialAds)
            self.bannerAds.removeAll()
        }else {
            self.advertisements.removeAll()
            self.advertisements.append(contentsOf:  self.bannerAds)
            self.interstitialAds.removeAll()
        }
    }
}

extension AppylarManager {
    
    internal static func checkInternetConnection() -> Bool {
        var zeroAddress = sockaddr_in()
        zeroAddress.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        zeroAddress.sin_family = sa_family_t(AF_INET)
        guard let defaultRouteReachability = withUnsafePointer(to: &zeroAddress, {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                SCNetworkReachabilityCreateWithAddress(nil, $0)
            }
        }) else {
            return false
        }
        var flags: SCNetworkReachabilityFlags = []
        if !SCNetworkReachabilityGetFlags(defaultRouteReachability, &flags) {
            return false
        }
        let isReachable = flags.contains(.reachable)
        let needsConnection = flags.contains(.connectionRequired)
        return (isReachable && !needsConnection)
    }
}
