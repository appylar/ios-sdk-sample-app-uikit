//
//  Current_Session.swift
//  Appylar SDK iOS
//
//  Created by 5Exceptions on 11/01/23.
//

import UIKit

public class Session {
    static var currentTask : URLSessionDataTask?
    static var sessionToken : String = ""
    static var appId : String = ""
    static var appKey: String = ""
    static var testMode = true
    public static var adTypes : [AdType] = []
    public static var orientations : [AdOrientation] = []
    static var rotationInterval = 0.0
    static var minimumBufferLimit = 1
    public static var printLog = false
    static var waitTime = 0
    static var waitTimeCountDownTimer : Timer?
    static var counterForErrorApiCalling: Int = 1
    static var isSessionCreated: Bool = false
    static var isInitialized: Bool = false
    static var isInterstitialShown: Bool = false
    static var isShowOneBannerOnly = false
    
    internal static func initializeSessionWith(token: String, appId: String, appKey: String, testMode: Bool, adTypes: [AdType], orientations : [AdOrientation],rotationInterval: Double, minimumBufferLimit: Int ) {
        
        Session.sessionToken = token
        Session.appId = appId
        Session.appKey = appKey
        Session.testMode = testMode
        Session.adTypes = adTypes
        Session.orientations = orientations
        Session.rotationInterval = rotationInterval
        Session.minimumBufferLimit = minimumBufferLimit
    }
    
    internal static func resetSession() {
        Session.sessionToken = ""
        Session.appId = ""
        Session.appKey = ""
        Session.adTypes = []
        Session.orientations = []
        Session.rotationInterval = 0.0
        AppylarManager.timer.invalidate()
        AppylarManager.timerForApiCallOn500.invalidate()
    }
}
