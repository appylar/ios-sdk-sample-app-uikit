//
//  ApiManager.swift
//  Appylar mobile SDK
//
//  Created by 5Exceptions on 15/12/22.
//

import UIKit

//MARK :-  Manager class for API calling
internal class ApiManager {
    
    //MARK :- Universal API call method with Request param and Completion Handler
    /**
     * Perform api calling
     * On Success return 200 status code
     * Onerror error Api is called
     *@completion is passed*
     * On 429 return a wait time and in other case wait time is 0
     */
    private func callApi(endPoint: String , requestType : RequestType, params : [String : Any], completionHandler: @escaping ([String : AnyObject]) -> Void) {
        let version = Bundle(identifier: "com.appylarios.io")?.infoDictionary?["CFBundleShortVersionString"] as? String  ?? ""
        let params = params as Dictionary<String, Any>
        if Session.printLog {
            print("Request body - \(params.debugDescription)")
        }
        let config = URLSessionConfiguration.default
        config.waitsForConnectivity = true
        config.timeoutIntervalForResource = 20
        
        var request = URLRequest(url: URL(string: Constants.baseUrl + endPoint)!)
        request.httpMethod = requestType.rawValue
        request.httpBody = try? JSONSerialization.data(withJSONObject: params, options: [])
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue( "Bearer " + Session.sessionToken, forHTTPHeaderField: "Authorization")
        request.addValue( "Appylar iOS/" + version, forHTTPHeaderField: "User-Agent")
        request.timeoutInterval = 20
        let session = URLSession(configuration: config)
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            if let errorReq = error as NSError?, errorReq.code == NSURLErrorTimedOut {
                if error != nil {
                    DispatchQueue.main.async {
                        if error?._code == -1001 {
                            var json = Dictionary<String, AnyObject>()
                            json[Constants.statusCode] = error?._code as AnyObject
                            completionHandler(json)
                        }
                    }
                }
            }
            else if error != nil {
                DispatchQueue.main.async {
                    if error?._code != -1009 {
                        if Session.printLog { print(error.debugDescription) }
                    }
                }
                return
            }
            else if let httpresponse = (response as? HTTPURLResponse) {
                if httpresponse.statusCode == 200 {
                    do {
                        var json = try JSONSerialization.jsonObject(with: data ?? Data()) as? Dictionary<String, AnyObject>
                        json?[Constants.statusCode] = httpresponse.statusCode as AnyObject
                        completionHandler(json ?? [String: AnyObject]())
                    } catch {
                        if Session.printLog {
                            print(Constants.error)
                        }
                    }
                } else if httpresponse.statusCode == 429 {
                    do {
                        if var json = try JSONSerialization.jsonObject(with: data ?? Data()) as? Dictionary<String, AnyObject> {
                            if let error = json[Constants.error] as? String {
                                if error == Constants.errorRateLimited {
                                    if let wait = json[Constants.wait] as? Int {
                                        DispatchQueue.main.async {
                                            if Session.waitTimeCountDownTimer == nil {
                                                Session.waitTime = Int(wait)
                                                if Session.printLog { print("Session waitTime", Session.waitTime)}
                                                json[Constants.statusCode] = httpresponse.statusCode as AnyObject
                                                completionHandler(json)
                                                Session.waitTimeCountDownTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                                                    if Session.waitTime > 0 {
                                                        Session.waitTime -= 1
                                                      } else {
                                                        Session.waitTimeCountDownTimer?.invalidate()
                                                        Session.waitTimeCountDownTimer = nil
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } catch {
                        if Session.printLog{
                            print(Constants.error)
                        }
                    }
                } else if httpresponse.statusCode == 401 {
                    do {
                        if var json = try JSONSerialization.jsonObject(with: data ?? Data()) as? Dictionary<String, AnyObject> {
                            if let error = json[Constants.error] as? String {
                                if error == Constants.errorUnauthorized {
                                    // Refreshing the Expired Session token
                                    self.handleError(json: json)
                                    Session.isInitialized = false
                                    json[Constants.statusCode] = httpresponse.statusCode as AnyObject
                                    if Session.sessionToken.isEmpty == false && endPoint != Constants.createSessionToken {
                                        var orientationRawValue = [String]()
                                        for or in Session.orientations {
                                            if !orientationRawValue.contains(or.rawValue){
                                                orientationRawValue.append(or.rawValue)
                                            }
                                        }
                                        let locale = Locale.current
                                        var countryCode = ""
                                        if #available(iOS 16, *) {
                                            if let value = locale.region?.identifier {
                                                countryCode = value
                                            }
                                        } else {
                                            if let value = locale.regionCode {
                                                countryCode = value
                                            }
                                        }
                                        let param = [
                                            Constants.width: Int(UIScreen.main.bounds.width),
                                            Constants.density: UIScreen.main.scale,
                                            Constants.height: Int(UIScreen.main.bounds.height),
                                            Constants.country: countryCode,
                                            Constants.language: NSLocale.current.languageCode ?? "en",
                                            Constants.appKey: Session.appKey,
                                            Constants.appId: Session.appId,
                                            Constants.testMode: Session.testMode,
                                            Constants.orientations: orientationRawValue
                                        ] as [String : Any]
                                        AppylarManager.timer.invalidate()
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                            self.callRefreshTokenApiWithRecursion(endPoint: endPoint, refreshTokenParams: param, params: params, requestType: requestType, completionHandler: completionHandler)
                                        }
                                        
                                    } else if Session.sessionToken != "" && endPoint == Constants.createSessionToken {
                                        Session.resetSession()
                                        self.handleError(json: json)
                                    }
                                }
                            }
                        }
                    } catch {
                        if Session.printLog{
                            print(Constants.error)
                        }
                    }
                }else if httpresponse.statusCode == 403 {
                    do {
                        if var json = try JSONSerialization.jsonObject(with: data ?? Data()) as? Dictionary<String, AnyObject> {
                            
                            if let error = json[Constants.error] as? String {
                                if error == Constants.errorForbidden {
                                    self.handleError(json: json)
                                    json[Constants.statusCode] = httpresponse.statusCode as AnyObject
                                    completionHandler(json)
                                }
                            }
                        }
                    } catch {
                        if Session.printLog{
                            print(Constants.error)
                        }
                    }
                }else if httpresponse.statusCode == 400{
                    do {
                        if let json = try JSONSerialization.jsonObject(with: data ?? Data()) as? Dictionary<String, AnyObject>{
                            AppylarManager.timer.invalidate()
                            if let _ = json[Constants.error] as? String {
                                self.handleError(json: json)
                            }
                        }
                    }catch {
                        if Session.printLog{
                            print(Constants.error)
                        }
                    }
                }else if httpresponse.statusCode == 500 {
                    do {
                        if var json = try JSONSerialization.jsonObject(with: data ?? Data()) as? Dictionary<String, AnyObject>{
                            json[Constants.statusCode] = httpresponse.statusCode as AnyObject
                            completionHandler(json)
                            if Session.counterForErrorApiCalling < 6 && Session.sessionToken.isEmpty == false{
                                Session.counterForErrorApiCalling += 1
                                var param = [String:Any]()
                                param[Constants.error] = json[Constants.error] as? String
                                self.callApiToCaptureError(params: param)
                            }
                        }
                    } catch {
                        if Session.printLog{
                            print(Constants.error)
                        }
                    }
                }
            }
        })
        task.resume()
    }
    
    //MARK :- API response Error Handler
    /**
     * Method for error handling
     * fired an event onError
     */
    internal func handleError(json:Dictionary<String, AnyObject>? ) {
        DispatchQueue.main.async {
            if let error = json{
                AppylarManager.delegate?.onError(error: error.description)
            }
        }
    }
    
    internal func callRefreshTokenApiWithRecursion(endPoint : String, refreshTokenParams : [String : Any], params : [String : Any] , requestType: RequestType,completionHandler : @escaping ([String : AnyObject])->() ) {
        
        if AppylarManager.checkInternetConnection() {
            self.callApiToCreateSessionToken(params: refreshTokenParams, orientations : Session.orientations, adTypes: Session.adTypes, completion: {
                // Call the previous api again
                DispatchQueue.main.asyncAfter(deadline: .now() + 30) {
                    self.callApi(endPoint: endPoint, requestType: requestType, params: params, completionHandler: completionHandler)
                }
            })
        } else {
            if Session.printLog{ print("No internet timee started for session")}
            DispatchQueue.main.asyncAfter(deadline: .now() + 30) {
                if Session.printLog { print("No internet timee ended for session")}
                self.callRefreshTokenApiWithRecursion(endPoint: endPoint, refreshTokenParams: refreshTokenParams, params: params, requestType: requestType, completionHandler: completionHandler)
            }
        }
    }
    
    //MARK :- Call API to Retrieve ADS
    /**
     * Perform Api caliing for retrieve Ads
     * In the case of 403 buffer is not called but in remaining case called
     */
    internal func callApiToRetrieveAds(extraParameters : [String : Any], combinations: [String : Any], completion: @escaping([String:Any]) -> ()) {
        let params = [
            Constants.extraParameters : extraParameters,
            Constants.combinations : combinations
        ] as [String : Any]
        self.callApi(endPoint: Constants.retrieveAds, requestType: .post, params: params) { json in
            if Session.printLog{
                print(json)
            }
            if json[Constants.statusCode] as? Int == 429 && Session.sessionToken.isEmpty == false{
                if Session.printLog{ print("Session timer for retrieve add 429", Session.waitTime) }
                DispatchQueue.main.asyncAfter(deadline: .now() + Double(Session.waitTime) , execute: {
                    if Session.printLog {print("Session wait time ended..")}
                    self.callApi(endPoint: Constants.retrieveAds, requestType: .post, params: params) { json in
                        self.startBufferTimer(json: json, combinations: combinations)
                    }
                })
            }else {
                self.startBufferTimer(json: json, combinations: combinations)
            }
        }
    }
    
    func startBufferTimer(json: [String: AnyObject], combinations: [String : Any]){
        if json[Constants.statusCode] as? Int == 200 {
            let responseAds = ResponseRetrieveAds()
            responseAds.initWithJson(json: json)
            if AppylarManager.advertisements.count > 0 {
                AppylarManager.advertisements.removeAll()
                AppylarManager.advertisements.append(contentsOf: responseAds.ads!)
                AppylarManager.bannerAds.append(contentsOf: AppylarManager().filterAds(filtertype: .banner))
                AppylarManager.interstitialAds.append(contentsOf: AppylarManager().filterAds(filtertype: .interstitial))
            } else {
                AppylarManager.advertisements = responseAds.ads ?? [Advertisement]()
                AppylarManager.bannerAds = AppylarManager().filterAds(filtertype: .banner)
                AppylarManager.interstitialAds = AppylarManager().filterAds(filtertype: .interstitial)
            }
            DispatchQueue.main.async {
                NotificationCenter.default.post(name: Notification.Name(rawValue: Constants.adRetrieveNotification), object: nil)
                if AppylarManager.timer.isValid == false {
                    // timer is still running
                    if Session.printLog{ print("timer started of 30secs for buffer if needed")}
                    AppylarManager.timer = Timer.scheduledTimer(withTimeInterval: 30, repeats: true) { _ in
                        if Session.printLog{  print("timer of 30 secs ended for buffer if needed")}
                        AppylarManager.checkExpireAdsPerAdType()
                        // statusCode = 403 - Do not retrieve ads
                        if json[Constants.statusCode] as! Int != 403 {
                            AppylarManager.bufferNewAdsIfNeeded(advertisement: AppylarManager.advertisements,combination: combinations)
                        }
                    }
                }
            }
        }
    }
    
    //MARK :- Call API to Create Session and initiate retrieve ads.
    /**
     * Perform Api calling for session creation
     * Session is created with given parameters
     */
    internal func callApiToCreateSessionToken(params: [String: Any], orientations : [AdOrientation], adTypes: [AdType], completion: @escaping () -> ()) {
        callingApi()
        
        func callingApi() {
            self.callApi(endPoint: Constants.createSessionToken, requestType: .post, params: params) { json in
                let orientations = orientations
                let adTypes = adTypes
                let testMode = params[Constants.testMode] as? Bool ?? false
                let appId = params[Constants.appId] as? String ?? ""
                let appKey = params[Constants.appKey] as? String ?? ""
                let rotationInterval = json[Constants.rotationInterval] as? Double ?? 0
                let bufferLimits = json[Constants.bufferLimits] as? [String: AnyObject] ?? [:]
                var minimumBufferLimit = 1
                if let min = bufferLimits[Constants.min] as? Int {
                    minimumBufferLimit = min
                }
                if let sessionToken = json[Constants.sessionToken] as? String {
                    //MARK :- initiate Session
                    Session.initializeSessionWith(token: sessionToken, appId: appId, appKey: appKey, testMode: testMode, adTypes: adTypes, orientations: orientations, rotationInterval: rotationInterval, minimumBufferLimit: minimumBufferLimit)
                    DispatchQueue.main.async {
                        AppylarManager.delegate?.onInitialized()
                        completion()
                    }
                }
                if json[Constants.statusCode] as! Int == 500 {
                    DispatchQueue.main.async {
                        if Session.printLog{  print("timer started for 500")}
                        DispatchQueue.main.asyncAfter(deadline: .now() + 30 , execute: {
                            if Session.printLog{  print("timer ended for 500")}
                            callingApi()
                        })
                    }
                } else if json[Constants.statusCode] as! Int == 429 {
                    DispatchQueue.main.async {
                        if Session.printLog{   print("timer started for 429")}
                        DispatchQueue.main.asyncAfter(deadline: .now() + Double(Session.waitTime) , execute: {
                            if Session.printLog {print("time ended 429")}
                            callingApi()
                        })
                    }
                }else if json[Constants.statusCode] as! Int == -1001 {
                    DispatchQueue.main.async {
                        if Session.printLog{   print("timer started for request time out")}
                        DispatchQueue.main.asyncAfter(deadline: .now() + 30, execute: {
                            if Session.printLog{   print("timer *Ended* for request time out")}
                            callingApi()
                        })
                    }
                }
            }
        }
    }
    
    //MARK :- Call API to Capture Error
    /**
     * Api  for error capturing
     * Recall Api with new endPoints
     */
    private func callApiToCaptureError(params : [String : Any]) {
        self.callApi(endPoint: Constants.captureError, requestType: .post, params: params) { json in
            if Session.printLog{
                print(json)
            }
        }
    }
}
