//
//  Constants.swift
//  Appylar mobile SDK
//
//  Created by 5Exceptions on 15/12/22.
//

import UIKit

internal class Constants{
    // Api constant
    static let baseUrl = "https://www.appylar.com"
    static let retrieveAds = "/api/v1/content/"
    static let captureError = "/api/v1/error/"
    static let createSessionToken = "/api/v1/session/"
    
    // Keys and Parameters
    static let width =  "width"
    static let density = "density"
    static let height = "height"
    static let country = "country"
    static let language = "language"
    static let appKey = "app_key"
    static let appId = "app_id"
    static let testMode = "test_mode"
    static let orientations = "orientations"
    static let sessionToken = "session_token"
    static let rotationInterval = "rotation_interval"
    static let bufferLimits = "buffer_limits"
    static let min = "min"
    static let error = "error"
    static let extraParameters = "extra_parameters"
    static let combinations = "combinations"
    static let scale = "scale"
    static let type = "type"
    static let result = "result"
    static let ad = "ad"
    static let orientation = "orientation"
    static let expiresAt = "expires_at"
    static let html = "html"
    static let url = "url"
    static let statusCode = "statusCode"
    static let adRetrieveNotification = "adRetrieveNotification"
    static let appKeyEmpty = "You didn't provide App-key"
    static let orientationEmpty = "You didn't provide an Orientation"
    static let adTypeEmpty = "You didn't provide Ad-Type"
    
    // Error Constant
    static let errorRateLimited = "err_rate_limited"
    static let errorUnauthorized = "err_unauthorized"
    static let errorForbidden = "err_forbidden"
    static let wait = "wait"
    static let errorInvalid = "err_invalid_data"
}
