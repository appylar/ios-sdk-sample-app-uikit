//
//  BannerView.swift
//  Appylar SDK iOS
//
//  Created by 5Exceptions on 06/01/23.
//

import UIKit
import WebKit
import SafariServices

public class BannerView: UIView, SFSafariViewControllerDelegate {
    
    //MARK:- Variables
    var webview = WKWebView()
    let contentController = WKUserContentController()
    var adDisplaying = false
    var rotationStoppedDueToNoAd = false
    var html = ""
    var webFrame = CGRect()
    var placement = ""
    var timerRotate = Timer()
    var bannerCounter = 0
    
    var isOnTop : Bool {
        if self.findViewController() == self.topViewController(){
            return true
        }
        return false
    }
    
    public func canShowAd() -> Bool{
        if AppylarManager.bannerAds.count > 0 {
            return  true
        } else {
            return false
        }
    }
    /**
     *Method for show Ads*
     *Start Ad rotation with position*
     *Fires notification every time when device orientations is changed*
     *@return void*
     */
    public func showAd(placement: String? = nil) {
        if self.adDisplaying == false && AppylarManager.bannerAds.count > 0 && Session.isShowOneBannerOnly == false {
            
            self.adDisplaying = true
            self.placement = placement ?? ""
            if AppylarManager.bannerAds.count > 0 {
                self.startAdRotation(placement: placement ?? "", isCallFromShowAd: true)
            }
            Session.isShowOneBannerOnly = true
            // Observer to get rotation of device
            NotificationCenter.default.addObserver(self, selector: #selector(rotated), name: UIDevice.orientationDidChangeNotification, object: nil)
            NotificationCenter.default.addObserver(self, selector: #selector(adPopulated), name: NSNotification.Name(rawValue: Constants.adRetrieveNotification), object: nil)
        } else {
            if self.adDisplaying == false && Session.isShowOneBannerOnly == false{
                AppylarManager.bannerDelegate?.onNoBanner()
            }
        }
    }
    
    override public func didMoveToSuperview() {
        BannerView.findAndSetHeightConstraintOfView(height: 0, view: self)
    }
    
    //MARK:- Manage orientation of banner ads
    /**
     *Frame of web view is changed according to UIScreen*
     *Called every time when notification is fired from showAds method*
     *@return void*
     */
    @objc func rotated() {
        if adDisplaying {
            if rotationStoppedDueToNoAd == false {
                for view in self.subviews {
                    if view is WKWebView {
                        view.removeFromSuperview()
                        self.layoutIfNeeded()
                    }
                }
            }
            self.rotationStoppedDueToNoAd == false ? loadWebView(htmlString: html, WebViewFrame: webFrame, placement: "") : nil
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                if UIDevice.current.orientation.isLandscape {
                    let frame = CGRect(x: 0, y: 0, width: self.bounds.width, height: self.bounds.height)
                    self.webview.frame = frame
                } else {
                    let frame = CGRect(x: 0, y: 0, width: self.bounds.width, height: self.bounds.height)
                    self.webview.frame = frame
                }
                self.layoutIfNeeded()
            }
        }
    }
    /**
     *Ads are rotating after rotation interval*
     *After a particular time interval this method is again in itself unitl there is no ads in buffer*
     *@return void*
     */
    private func startAdRotation(placement: String, isCallFromShowAd: Bool) {
        if self.adDisplaying == true {
            if AppylarManager.bannerAds.count > 0 {
                
                let adToShow = AppylarManager.bannerAds.first { ad in
                    ad.isExpired == false && ad.adDisplayed == false
                }
                adToShow?.adDisplayed = true
                var frame = CGRect()
                if adToShow != nil {
                    isCallFromShowAd ? AppylarManager.bannerDelegate?.onBannerShown() : nil
                    self.rotationStoppedDueToNoAd = false
                    let html = adToShow?.html ?? ""
                    let _ = adToShow?.ad?.width ?? 0
                    let adheight = adToShow?.ad?.height ?? 0
                    DispatchQueue.main.async {
                        let viewWidth = self.bounds.width
                        frame = CGRect(x: 0 , y: 0, width: viewWidth, height: adheight)
                        self.loadWebView(htmlString: html, WebViewFrame: frame,placement: placement)
                    }
                    DispatchQueue.main.async{ [self] in
                        if self.isOnTop == true {
                            var rotationTime = Session.rotationInterval
                            timerRotate = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] timerRotate in
                                if Session.isInterstitialShown == false {
                                    self?.bannerCounter += 1
                                    if Session.printLog{
                                        print("Banner rotations interval: ",self?.bannerCounter as Any)
                                    }
                                    if self?.bannerCounter == Int(rotationTime){
                                        self?.bannerCounter = 0
                                        self?.startAdRotation(placement: placement, isCallFromShowAd: false)
                                        rotationTime = Session.rotationInterval - Double(self!.bannerCounter)
                                        self?.timerRotate.invalidate()
                                    }
                                }else {
                                    if Session.printLog{
                                        print("Timer paused for banner:",self?.bannerCounter as Any)
                                    }
                                }
                            }
                        } else {
                            self.checkIfViewIsOnTop()
                        }
                    }
                } else {
                    self.rotationStoppedDueToNoAd = true
                }
            } else {
                self.rotationStoppedDueToNoAd = true
            }
        }
    }
    
    private static func findAndSetHeightConstraintOfView(height : CGFloat, view: UIView) {
        var foundHeightConstraint = false
        let constraints = view.constraints
        
        for constraint in constraints {
            if constraint.isActive && constraint.firstAttribute == .height {
                constraint.constant = height
                foundHeightConstraint = true
            }
        }
        
        if foundHeightConstraint == false {
            view.frame = CGRect(x: view.frame.minX, y: view.frame.minY, width: view.frame.width, height: height)
            let constraint = NSLayoutConstraint(item: view, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1, constant: height)
            constraint.isActive = true
            view.addConstraint(constraint)
        }
    }
    
    /**
     *Check the position of Banner*
     *@return void*
     */
    private func checkIfViewIsOnTop () {
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            if self.isOnTop == true {
                self.startAdRotation(placement: self.placement, isCallFromShowAd: true)
            } else {
                self.checkIfViewIsOnTop()
            }
        }
    }
    /**
     *Method for webview*
     *Url is loaded in this*
     *@return void*
     */
    private func loadWebView(htmlString: String, WebViewFrame: CGRect,placement: String) {
        
        if webFrame != WebViewFrame {
            for view in self.subviews {
                if view is WKWebView {
                    view.removeFromSuperview()
                    self.layoutSubviews()
                }
            }
        }
        html = htmlString
        webFrame = WebViewFrame
        let config = WKWebViewConfiguration()
        let source: String = "var meta = document.createElement('meta');" +
        "meta.name = 'viewport';" +
        "meta.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';" +
        "var head = document.getElementsByTagName('head')[0];" +
        "head.appendChild(meta);"
        
        let script: WKUserScript = WKUserScript(source: source, injectionTime: .atDocumentEnd, forMainFrameOnly: true)
        let userContentController: WKUserContentController = WKUserContentController()
        config.userContentController = userContentController
        userContentController.addUserScript(script)
        config.userContentController.add(self, name: "closed")
        config.preferences.javaScriptCanOpenWindowsAutomatically = true
        if #available(iOS 14.0, *) {
            config.defaultWebpagePreferences.allowsContentJavaScript = true
        }
        webview = WKWebView(frame: WebViewFrame, configuration: config)
        webview.isOpaque = false
        webview.removeFromSuperview()
        self.addSubview(webview)
        webview.navigationDelegate = self
        webview.uiDelegate = self
        webview.loadHTMLString(htmlString.replacingOccurrences(of: "%PLACEMENT%", with: placement.addingPercentEncoding(withAllowedCharacters: .urlUserAllowed) ?? ""), baseURL: nil)
        BannerView.findAndSetHeightConstraintOfView(height: webview.frame.height, view: self)
    }
    /**
     *Hide the  Banner from view*
     *Set adDisplaying false*
     *@return void*
     */
    public func hideAd() {
        self.rotationStoppedDueToNoAd = false
        if Session.printLog {print("Banner Hidden")}
        for view in self.subviews {
            if view is WKWebView {
                view.removeFromSuperview()
                self.layoutSubviews()
            }
        }
        Session.isShowOneBannerOnly = false
        timerRotate.invalidate()
        bannerCounter = 0
        self.adDisplaying = false
        BannerView.findAndSetHeightConstraintOfView(height: 0, view: self)
    }
    
    @objc func adPopulated() {
        if self.adDisplaying == true && self.rotationStoppedDueToNoAd == true {
            self.startAdRotation(placement: self.placement, isCallFromShowAd: false)
        }
    }
}

extension BannerView: WKUIDelegate, WKNavigationDelegate, WKScriptMessageHandler {
    
    public func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
    }
    /**
     *Perform navigation of webview on safari *
     *Return wkWebView*
     */
    public func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        
        if let url = navigationAction.request.url, UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.open(url)
        }
        return nil
    }
}
