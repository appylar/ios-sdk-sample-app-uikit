//
//  AdViewController.swift
//  Appylar SDK iOS
//
//  Created by 5Exceptions on 13/01/23.
//

import UIKit
import WebKit
import SafariServices

open class InterstitialViewController: UIViewController, WKNavigationDelegate, WKUIDelegate {
    var webview = WKWebView()
    let contentController = WKUserContentController()
    var adDisplaying = false {
        didSet {
            if adDisplaying == true {
                var orientationMask : UIInterfaceOrientationMask?
                switch UIDevice.current.orientation {
                case .unknown:
                    orientationMask = .portrait
                case .portrait,.faceUp, .faceDown:
                    orientationMask = .portrait
                case .portraitUpsideDown:
                    orientationMask = .portraitUpsideDown
                case .landscapeLeft:
                    orientationMask = .landscapeRight
                case .landscapeRight:
                    orientationMask = .landscapeLeft
                @unknown default:
                    orientationMask = .portrait
                }
                AppylarManager.supportedOrientation = orientationMask ?? .portrait
            } else {
                AppylarManager.supportedOrientation = .all
            }
            
            if #available(iOS 16.0, *) {
                self.setNeedsUpdateOfSupportedInterfaceOrientations()
            }
        }
    }
    
    open override func viewDidLoad() {
        super.viewDidLoad()
        self.webview.scrollView.isScrollEnabled = false
        if #available(iOS 16.0, *) {
            self.webview.isFindInteractionEnabled = true
        }
    }
    
    open override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return AppylarManager.supportedOrientation
    }
    
    open override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    public static func canShowAd() -> Bool {
        if  AppylarManager.interstitialAds.count > 0 {
            return true
        }
        else {
            return false
        }
    }
    /**
     *Method for show Ads*
     *Start Ad rotation with position*
     *@return void*
     */
    public func showAd(placement: String? = nil) {
        if adDisplaying == false {
            adDisplaying = true
            showAdInternal(placement: placement ?? "")
        }
    }
    /**
     *Ads are rotating after rotation interval*
     *@return void*
     */
    private func showAdInternal(placement: String) {
        if adDisplaying == true {
            if AppylarManager.interstitialAds.count > 0 {
                var adToShow = AppylarManager.interstitialAds.first { ad in
                    ad.isExpired == false && ad.adDisplayed == false
                }
                adToShow?.adDisplayed = true
                if adToShow == nil {
                    let unexpiredAds = AppylarManager.interstitialAds.filter { ad in
                        ad.isExpired == false
                    }
                    let unexpiredAd = unexpiredAds.randomElement()
                    adToShow = (unexpiredAd != nil) ? unexpiredAd : AppylarManager.interstitialAds.randomElement()
                }
                Session.isInterstitialShown = true
                DispatchQueue.main.async {
                    let html = adToShow?.html ?? ""
                    self.loadWebVIew(htmlString: html,placement: placement)
                }
                AppylarManager.interstitialDelegate?.onInterstitialShown()
            } else {
                adDisplaying = false
                AppylarManager.interstitialDelegate?.onNoInterstitial()
            }
        }
    }
    
    /**
     *Method for webview*
     *Url is loaded in this*
     *@return void*
     */
    private func loadWebVIew(htmlString: String,placement: String) {
        let config = WKWebViewConfiguration()
        let source: String = "var meta = document.createElement('meta');" +
        "meta.name = 'viewport';" +
        "meta.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';" +
        "var head = document.getElementsByTagName('head')[0];" +
        "head.appendChild(meta);"
        let script: WKUserScript = WKUserScript(source: source, injectionTime: .atDocumentEnd, forMainFrameOnly: true)
        let userContentController: WKUserContentController = WKUserContentController()
        config.userContentController = userContentController
        userContentController.addUserScript(script)
        config.userContentController.add(self, name: "closed")
        // Create a web view configuration
        config.preferences.javaScriptCanOpenWindowsAutomatically = true
        if #available(iOS 14.0, *) {
            config.defaultWebpagePreferences.allowsContentJavaScript = true
        }
        let window = UIApplication.shared.keyWindow
        if #available(iOS 11.0, *) {
            //     let topPadding = window?.safeAreaInsets.top
            let leftPadding = window?.safeAreaInsets.left
            let rightPadding = window?.safeAreaInsets.right
            let totalPaddingHorizontal = (leftPadding ?? 0) + (rightPadding ?? 0)
            let frame = CGRect(x: leftPadding ?? 0, y: 0, width: UIScreen.main.bounds.width - totalPaddingHorizontal, height: UIScreen.main.bounds.height)
            webview = WKWebView(frame: frame, configuration: config)
        }
        webview.navigationDelegate = self
        webview.uiDelegate = self
        webview.scrollView.alwaysBounceHorizontal = false
        webview.scrollView.alwaysBounceVertical = false
        webview.contentMode = .scaleToFill
        view.addSubview(webview)
        webview.loadHTMLString(htmlString.replacingOccurrences(of: "%PLACEMENT%", with: placement.addingPercentEncoding(withAllowedCharacters: .urlUserAllowed) ?? ""), baseURL: nil)
    }
    /**
     *Hide the  Interstitial from view*
     *@return void*
     */
    private func hideInterstitialAd() {
        for view in self.view.subviews {
            if view == self.webview {
                view.removeFromSuperview()
            }
        }
        Session.isInterstitialShown = false
        AppylarManager.interstitialDelegate?.onInterstitialClosed()
    }
}


extension InterstitialViewController : WKScriptMessageHandler, SFSafariViewControllerDelegate {
    
    open func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        if(message.name == "closed") {
            userContentController.removeScriptMessageHandler(forName: "closed")
            if #available(iOS 14.0, *) {
                userContentController.removeAllScriptMessageHandlers()
            }
            userContentController.removeAllUserScripts()
            hideInterstitialAd()
        }
        Session.isInterstitialShown = false
        adDisplaying = false
        NotificationCenter.default.post(name: UIDevice.orientationDidChangeNotification, object: nil)
    }
    
    
    /**
     *Perform navigation of webview on safari *
     *Return wkWebView*
     */
    public func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        guard let url = URL(string: navigationAction.request.url?.absoluteString ?? "") else {
            return webView }
        webView.stopLoading()
        //webview
        let safariVC = SFSafariViewController(url: url)
        safariVC.delegate = self
        present(safariVC, animated: true, completion: nil)
        return nil
    }
}

